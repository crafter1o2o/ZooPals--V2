﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooPal_LikeThePlates_
{
    internal class Goodbye
    {// Displays a goodbye message
        /// <summary>
        /// I did this to try and have something say "Hey! I'm done running now!" -PCB
        /// </summary>
        public static void displayGoodbye()
        {
            Console.WriteLine("Thank you for using Zoo Pal System! Goodbye!");
        }
    }
}

