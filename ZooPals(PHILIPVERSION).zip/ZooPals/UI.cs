﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooPal
{
    internal class UI
    {
        // Displays the main menu
        /// <summary>
        /// I did this out of pure bordom. Sorry Ben! -PCB
        /// </summary>
        public static void DisplayMenu()
        {
            Console.WriteLine("-------Zoo Pal Zoo-------");
            Console.WriteLine("1. Display Animals");
            Console.WriteLine("2. Display Habitats");
            Console.WriteLine("3. Feed All Animals");
            Console.WriteLine("4. Perform Health Checks");
            Console.WriteLine("5. Add New Animal");
            Console.WriteLine("6. Generate Daily Report");
            Console.WriteLine("7. Demostrate Polymorphism");
            Console.WriteLine("8. Emergency Evacuation Drill");
            Console.WriteLine("9. Exit");
            Console.WriteLine("-------------------------");


        }
    }
}
