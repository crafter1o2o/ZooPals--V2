﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooPal.Animals
{
    internal class Elephant
    {

        public double TrunkLength;
        public double TuskLength;

        public Elephant(String name, int age, double weight, double trunkLength, double tuskLength)
        {

        }
        /*
        public string MakeSound()
        {

        }

        public string GetDietType()
        {

        }

        public double GetFoodAmount()
        {

        }
        public void Feed()
        {

        }

        public void DisplayInfo()
        {

        }
        */
    }
}
